from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import *
from django.db.models import Q
from itertools import chain
from operator import attrgetter
from .forms import *
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy

def main(request):
    home_photos = HomePhoto.objects.select_related('photo').all()
    name = get_object_or_404(PhotographerName, pk=1)
    services = Service.objects.all().order_by('order')
    
    context = {
    'home_photos': home_photos ,
    'name' : name ,
    'services': services
    }
    return render(request, 'main.html', context)

    
   
    
    
    
    
#gallery-page
def gallery(request):
    photos = Photo.objects.all().order_by('-uploaded_at')
    videos = Video.objects.all().order_by('-uploaded_at')
    
    all_items = sorted(
        chain(photos, videos),
        key=attrgetter('uploaded_at'),
        reverse=True
    )
    
    # Add a 'type' attribute to each item
    for item in all_items:
        item.type = 'photo' if isinstance(item, Photo) else 'video'
    
    context = {
        'all_items': all_items,
        'photos': photos,
        'videos': videos,
    }
    return render(request, 'photo_list.html', context)
    
#uplod-photo     

@login_required(login_url=reverse_lazy('login'))       
def upload_photo(request):
    if request.method == 'POST':
        form = PhotoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            photo = form.save(commit=False)
            photo.save()
            messages.success(request, 'Photo uploaded successfully!')
            return redirect('photo')  # Assume you have a view to list photos
    else:
        form = PhotoUploadForm()
    
    return render(request, 'head/upload_photo.html', {'form': form})
    
    
# upload-video
from django.shortcuts import render, redirect
from .forms import VideoUploadForm

@login_required(login_url=reverse_lazy('login'))
def upload_video(request):
    if request.method == 'POST':
        form = VideoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('photo')  # Redirect to video list page
    else:
        form = VideoUploadForm()
    return render(request, 'head/upload_video.html', {'form': form})    
    




#additional
def about(request):
    name = get_object_or_404(PhotographerName, pk=1)
    context = AboutDetail.objects.filter(pk=1).first()
    equipment = Equipment.objects.all()
    philosophy = Philosophy.objects.filter(pk=1).first()


    context = {
    'name': name ,
    'context' : context ,
    'equipment': equipment, 
    'philosophy' : philosophy
    }
    return render(request, 'addition/about.html', context)





from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dash')  # Redirect to home page after successful login
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'head/login.html')
    
    
    
    
    
    
    
def contact(request):
    whatsapp = Whatsapp.objects.filter(pk=1).first()
    instagram = Instagram.objects.filter(pk=1).first()
    gmail = Gmail.objects.filter(pk=1).first()
    facebook = Facebook.objects.filter(pk=1).first()
    
    
    context = {
    'whatsapp' : whatsapp,
    'instagram' : instagram,
    'gmail' : gmail,
    'facebook' : facebook,
    }
    return render(request, 'addition/contact.html' , context)
    
    

@login_required(login_url=reverse_lazy('login'))
def dash(request):
    return render(request, 'head/dash.html')