from django.core.management.base import BaseCommand
from django.contrib.auth.models import User

# Try importing colorama
try:
    from colorama import Fore, Style, init
    init(autoreset=True)  # Automatically reset color after each line
    colorama_installed = True
except ImportError:
    colorama_installed = False

class Command(BaseCommand):
    help = 'Create a new user'

    def handle(self, *args, **kwargs):
        # Prompt for username
        username = input("Enter username: ")
        
        # Check if the username already exists
        if User.objects.filter(username=username).exists():
            message = f"User with username '{username}' already exists."
            if colorama_installed:
                self.stdout.write(Fore.RED + message)
            else:
                self.stdout.write(message)
            return
        
        # Prompt for password (visible input)
        password = input("Enter password: ")
        password_confirm = input("Confirm password: ")

        if password != password_confirm:
            message = "Passwords do not match."
            if colorama_installed:
                self.stdout.write(Fore.RED + message)
            else:
                self.stdout.write(message)
            return

        # Create and save the user
        user = User.objects.create_user(username=username, password=password)
        user.save()

        message = f"User '{username}' created successfully."
        if colorama_installed:
            self.stdout.write(Fore.GREEN + message)
        else:
            self.stdout.write(message)