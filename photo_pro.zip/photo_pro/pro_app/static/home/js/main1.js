        const menuToggle = document.getElementById('menu-toggle');
        const mobileMenu = document.getElementById('mobile-menu');
        const header = document.querySelector('header');

        menuToggle.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
            mobileMenu.firstElementChild.classList.toggle('-translate-y-full');
            menuToggle.classList.toggle('open');

            // Animate the menu icon to a cross
            menuToggle.children[0].classList.toggle('rotate-45');
            menuToggle.children[0].classList.toggle('translate-y-1.5');
            menuToggle.children[1].classList.toggle('opacity-0');
            menuToggle.children[2].classList.toggle('-rotate-45');
            menuToggle.children[2].classList.toggle('-translate-y-1.5');
        });

        // Change header background on scroll
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.firstElementChild.classList.add('bg-white/90', 'backdrop-blur-sm');
                header.firstElementChild.classList.remove('bg-white');
            } else {
                header.firstElementChild.classList.remove('bg-white/90', 'backdrop-blur-sm');
                header.firstElementChild.classList.add('bg-white');
            }
        });

        // Typing effect
        var typed = new Typed('#typing-effect', {
            strings: ['landscape', 'wedding', 'birthday'],
            typeSpeed: 100,
            backSpeed: 50,
            backDelay: 2000,
            loop: true,
            showCursor: true,
            cursorChar: '|'
        });

        // Smooth scroll for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Intersection Observer for fade-in-up animation
        const fadeInUpObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                    fadeInUpObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });

        document.querySelectorAll('.fade-in-up').forEach(el => {
            el.style.opacity = '0';
            fadeInUpObserver.observe(el);
        });