  $(document).ready(function() {
        // Double-click to fullscreen functionality
        let lastClickTime = 0;
        const doubleClickDelay = 300; // milliseconds

        document.querySelectorAll('.photo-item').forEach(photo => {
            photo.addEventListener('click', function(e) {
                const currentTime = new Date().getTime();
                const timeSinceLastClick = currentTime - lastClickTime;

                if (timeSinceLastClick < doubleClickDelay) {
                    // Double click detected
                    const fullscreenOverlay = document.getElementById('fullscreen-overlay');
                    const fullscreenImage = document.getElementById('fullscreen-image');
                    
                    fullscreenImage.src = this.src;
                    fullscreenOverlay.style.display = 'flex';
                }

                lastClickTime = currentTime;
            });
        });

        // Close fullscreen overlay
        document.getElementById('close-button').addEventListener('click', function() {
            document.getElementById('fullscreen-overlay').style.display = 'none';
        });

        // Close fullscreen when clicking outside the image
        document.getElementById('fullscreen-overlay').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });