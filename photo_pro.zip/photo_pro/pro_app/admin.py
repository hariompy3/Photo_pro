

from django.contrib import admin
from .models import *

admin.site.register(Photo)
admin.site.register(Video)

admin.site.register(HomePhoto)
admin.site.register(PhotographerName)
admin.site.register(AboutDetail)
admin.site.register(Equipment)
admin.site.register(Philosophy)
admin.site.register(Service)

# Registering the models with the admin panel
admin.site.register(Whatsapp)
admin.site.register(Instagram)
admin.site.register(Gmail)
admin.site.register(Facebook)
#from django.contrib import admin
#from .models import Photo, Video, HomePhoto

# Media Management Section
#class PhotoAdmin(admin.ModelAdmin):
#    list_display = ('title', 'uploaded_at', 'width', 'height')
#    group = 'Media Management'  # This is for grouping (though Django does not use `group` directly)

#class VideoAdmin(admin.ModelAdmin):
#    list_display = ('title', 'uploaded_at')
#    group = 'Media Management'

# Home Page Content Section
#class HomePhotoAdmin(admin.ModelAdmin):
#    list_display = ('photo', 'order')
#    group = 'Home Page Content'

# Registering models with custom sections
#admin.site.register(Photo, PhotoAdmin)
admin.site.register(User)
#admin.site.register(HomePhoto, HomePhotoAdmin)