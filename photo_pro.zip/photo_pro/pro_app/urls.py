
# pro_app/urls.py
from django.urls import path
from . import views

urlpatterns = [
    #landing page 
    path('', views.main, name='home'),
    
    #gallery
    path('gallery/', views.gallery, name='photo'),
    path('upload-photo/', views.upload_photo, name='upload_photo'),
    path('upload-video/', views.upload_video, name='upload_video'),
    
    
    #additional
    path('about/', views.about, name='about'),
    
    
    path('login/', views.login_view, name='login'),
    
    
    path('contact/', views.contact, name='contact'),
    
    
    path('dash/', views.dash, name='dash'),
    
    
    

]